import React from 'react';
import axios from 'axios'
// Components
import RobotSvg from './RobotSvg';
import botGif from '../assets/bot.gif'
import Lottie from 'lottie-react';
import xfoodPng from '../assets/xfood.png';

//Lottie files
import loadingDots from '../assets/loading-dots.json';

//Icons

import { IoMdClose } from "react-icons/io";
import { AiOutlineSend } from "react-icons/ai";

//Images
import chatRobot from '../assets/chat-robot.png'
import userImage from '../assets/user.png'


function ChatBot() {

  const Message = ({type, msg, extra}) =>{
    return(
      <div className={`message-container ${type === 'bot' ?'':'user-sender'}`}>
        
        <div className='sender-image-container'>
          <img width={35} height={35} src={type === 'bot' ?chatRobot : userImage} />
        </div>

        <div className='messages-container'>
          <div style={extra ? {boxShadow:'unset'}:{}} className='messages'>
            {msg}
          </div>
        </div>
        
      </div>
    )
  }

  const robotRef = React.useRef(null);
  const chatRef = React.useRef(null);

  const [chatVisible,setChatVisible] = React.useState(false);
  const [isLoading,setIsLoading] = React.useState(false);
  const handleClick = ()=>{
    setChatVisible((prev) =>{
      return !prev
    })
  }

  const handleClose = () =>{
    setChatVisible(false)
  }

  const handleMouseDown = ()=>{
    robotRef.current.classList.add('mouse-on')
  }
  
  const handleMouseUp = ()=>{
    robotRef.current.classList.remove('mouse-on')
  }

  //Chat state
  const [userText,setUserText] = React.useState('');
  const [chat,setChat] = React.useState([]);
  const [messagesElements,setMessagesElements] = React.useState([]);

  const handleUserText = (e) =>{
    const textValue = e.target.value
    setUserText(textValue)
  }

  
  //Send a Msg

  const sendMsg = async(e) =>{
    e.preventDefault()
    if(userText.length === 0)
    return;

    setIsLoading(true);
    setMessagesElements((prevMsgs) =>{
      return [prevMsgs,<Message
                       key={prevMsgs.length + 1}
                       id={prevMsgs.length + 1}
                       msg={userText}
                       type='user'
                       createdAt={new Date().toString()}/>
                      ].flat()
    })
    setUserText('');
    setTimeout(() =>{
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    },1);
    setTimeout(async() =>{
      const { data }  = await axios.post('https://xfood-ob2l.onrender.com/send-msg',
      {msg:userText},
      {withCredentials:true});
   const botResponse = data.msg.msg; 
      const botFunction = data.msg.function
      let isFunction = false
      let chatObj = {}      
      if(botFunction === 'recommendations'){
        const pArray = JSON.parse(botResponse);
        let products = await axios.get('https://xfood-ob2l.onrender.com/products');
        const forProducts = products.data.map((item) =>{
          let exist = false;
          for(let i = 0; i < pArray.length; i++)
          {
            if(pArray[i] === item._id)
            {
              exist = true ;
              break;
            }
              
          }
          if(exist)
          return item 
          else
          return null

        }).filter(item => item != null)

        let recString = '';
        forProducts.map((item,index) =>{
          if(index === 0)
          {
            recString += `Certainly! we can recommend you ${item.title} in the ${item.category} category , `

          }
          else if(index != (forProducts.length - 1)){
            recString += `${item.title} in the ${item.category} category, `

          }
          else{
            recString += `and finally ${item.title} in the ${item.category} category .`

          }
        })

        chatObj ={
          userMessage:userText,
          botMessage:recString,
          createdAt:new Date().toString()
        }
        isFunction = true

      }
      if(botFunction === 'Order')
      {
        for(let i = 0; i < botResponse.length; i++)
        {
          const response = await axios.post('https://xfood-ob2l.onrender.com/add-to-cart',{
            productId:botResponse[i].productId,
            productQuantity:botResponse[i].productQuantity,
            size:botResponse[i].size,
            extras:botResponse[i].extras
  
          },{withCredentials:true})
  
        }
       

        chatObj ={
          userMessage:userText,
          botMessage:data.msg.botString,
          createdAt:new Date().toString()
        }
        isFunction = true
      }

      if(botFunction === 'Menu')
      {
        const menu = botResponse
        let menuString = `certainly! : \n`;

        menu.map((item,index) =>{
          if(index === 0)
          {
            menuString += `We have ${item.title} in the ${item.category} category with price of ${item.price} EGP, `

          }
          else if(index != (menu.length - 1)){
            menuString += `${item.title} in the ${item.category} category with price of ${item.price} EGP, `

          }
          else{
            menuString += `and finally ${item.title} in the ${item.category} category with price of ${item.price} EGP.`

          }
        })
        chatObj ={
          userMessage:userText,
          botMessage:menuString,
          createdAt:new Date().toString()
        }
        isFunction = true
      }



      if (!isFunction){
        chatObj ={
          userMessage:userText,
          botMessage:botResponse,
          createdAt:new Date().toString()
        }
      }
 
  
      if(chat.length === 0)
      {
        localStorage.setItem('chat',JSON.stringify([chatObj]))
        setChat(() =>{
          return [chatObj]
        })
        setTimeout(() =>{
          chatRef.current.scrollTop = chatRef.current.scrollHeight;
        },1);
        setIsLoading(false)

      }
      else{
        setChat((prevChat) =>{
          const newChat = [prevChat,chatObj].flat();
          localStorage.setItem('chat',JSON.stringify(newChat))
          return newChat
        })
        setTimeout(() =>{
          chatRef.current.scrollTop = chatRef.current.scrollHeight;
        },1);
        setIsLoading(false)
      }
    },2000)
   

  }

  // Get previous chat

  React.useEffect(() =>{
    try {
      const chatData = localStorage.getItem('chat');
      if(!chatData)
      return;

      setChat(JSON.parse(chatData))
      setTimeout(() =>{
        chatRef.current.scrollTop = chatRef.current.scrollHeight;
      },700);

    } catch (error) {
      console.log(error)
    }
    
  },[0])

  // Set messages
  React.useEffect(() =>{

    let formatted_messages = []

    chat.map((item) =>{
      formatted_messages.push({msg:item.userMessage,type:'user',createdAt:item.createdAt});
      formatted_messages.push({msg:item.botMessage,type:'bot',createdAt:item.createdAt});

    });

    setMessagesElements(() =>{
      return formatted_messages.map((item,index) =>{
        return <Message
                key={index + 1}
                id={index + 1}
                msg={item.msg}
                type={item.type}
                createdAt={item.createdAt}
               />
      })
    })


  },[chat])
  

  return (
    <div className='chat-bot'>

        <div className='chat-bot-content'>

          <div className={`chat-container ${chatVisible ? 'scale-up':''}`}>

            <div className='chat-title'>
                <div className='title-content'>
                  <div className='logo-cont'><img draggable={false} className='logo' width={40} height={38} src={xfoodPng} /></div>
                  <div>XFOOD SUPPORT</div>
                </div>

                <div className='title-close-container'>
                  <IoMdClose onClick={handleClose}  size={24} className='title-close-icon'/>
                </div>
            </div>

            <div className='chat-body'>

              <div ref={chatRef} className='chat-body-content'>
                <Message msg={'Hey!👋 XFOOD here, How can i help'} type='bot'/>
                {
                  messagesElements
                }
                {
                isLoading && 
                <Message
                 extra={true}
                 type='bot' 
                 msg={<Lottie className='loading-dots' animationData={loadingDots}/>}
                 />
                }
              </div>

            </div>


            <div className='send-msg-container'>

              <form onSubmit={sendMsg} className='send-msg'>
                <input 
                name='message'
                value={userText}
                onChange={handleUserText} 
                placeholder='Type your message here...' className='msg-inpt' type='text'/>
              </form>

              <div className='send-msg-btn-container'>
                <AiOutlineSend onClick={sendMsg} fill='gray' className='send-arrow'/>
              </div>

            </div>


          </div>

          <div ref={robotRef}
          onMouseUp={handleMouseUp}
          onMouseDown={handleMouseDown}
          onMouseLeave={handleMouseUp}
          onClick={handleClick}
          className='robot-container'>
           <img className='robot-svg' width={40} height={35} src={chatRobot}/>
          </div>



        </div>


    </div>
  )
}

export default ChatBot